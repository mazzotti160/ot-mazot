local condition = Condition(CONDITION_REGENERATION, CONDITIONID_DEFAULT)
condition:setParameter(CONDITION_PARAM_SUBID, 88888)
condition:setParameter(CONDITION_PARAM_TICKS, 7 * 1000)
condition:setParameter(CONDITION_PARAM_HEALTHGAIN, 0.01)
condition:setParameter(CONDITION_PARAM_HEALTHTICKS, 7 * 1000)

local gazHaragothHeal = CreatureEvent("Arenator")

local function participantTimer()
    for _, cid in ipairs(Game.getPlayers()) do
        local participant = Player(cid)
        if participant and participant:isPlayer() then
            local storageValue = participant:getStorageValue(453565651409)
            if storageValue < 1 then
                participant:setStorageValue(453565651409, 0) -- 0-60 seconds
                participant:say("Arena started! Each wave lasts 60 seconds. GOOD LUCK!", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 0 then
                participant:setStorageValue(453565651409, 1) -- 61-120 seconds
                participant:say("Wave 1 finished, starting wave 2.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 1 then
                participant:setStorageValue(453565651409, 2) -- 121-180 seconds
                participant:say("Wave 2 finished, starting wave 3.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 2 then
                participant:setStorageValue(453565651409, 3) -- 181-240 seconds
                participant:say("Wave 3 finished, starting wave 4.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 3 then
                participant:setStorageValue(453565651409, 4) -- 241-300 seconds
                participant:say("Wave 4 finished, starting wave 5.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 4 then
                participant:setStorageValue(453565651409, 5) -- 301-361 seconds
                participant:say("Wave 5 finished, starting wave 6.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 5 then
                participant:setStorageValue(453565651409, 6) -- 421-480 seconds
                participant:say("Wave 6 finished, starting wave 7.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 6 then
                participant:setStorageValue(453565651409, 7) -- 481-540 seconds
                participant:say("Wave 7 finished, starting wave 8.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 7 then
                participant:setStorageValue(453565651409, 8) -- 541-600 seconds
                participant:say("Wave 8 finished, starting wave 9.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 8 then
                participant:setStorageValue(453565651409, 9) -- 601-660 seconds
                participant:say("Wave 9 finished, starting wave 10.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 9 then
                participant:setStorageValue(453565651409, 10) -- 661-720 seconds
                participant:say("Wave 10 finished, starting wave 11.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 10 then
                participant:setStorageValue(453565651409, 11) -- 721-780 seconds
                participant:say("Wave 11 finished, starting wave 12.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 11 then
                participant:setStorageValue(453565651409, 12) -- 781-840 seconds
                participant:say("Wave 12 finished, starting wave 13.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 12 then
                participant:setStorageValue(453565651409, 13) -- 841-900 seconds
                participant:say("Wave 13 finished, starting wave 14.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 13 then
                participant:setStorageValue(453565651409, 14) -- 901-960 seconds
                participant:say("Wave 14 finished, starting wave 15.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 14 then
                participant:setStorageValue(453565651409, 15) -- 1021-1080 seconds
                participant:say("Wave 15 finished, starting wave 16.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 15 then
                participant:setStorageValue(453565651409, 16) -- 1081-1140 seconds
                participant:say("Wave 16 finished, starting wave 17.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 16 then
                participant:setStorageValue(453565651409, 17) -- 1141-1220 seconds
                participant:say("Wave 17 finished, starting wave 18.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 17 then
                participant:setStorageValue(453565651409, 18) -- 1221-1280 seconds
                participant:say("Wave 18 finished, starting wave 19.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 18 then
                participant:setStorageValue(453565651409, 19) -- 1281-1240 seconds
                participant:say("Wave 19 finished, starting wave 20.", TALKTYPE_MONSTER_YELL)
            elseif storageValue == 19 then
                participant:setStorageValue(453565651409, 20) -- 1241-1300 seconds
                participant:say("Wave 20 finished, CONGRATULATIONS! You finished arena and got maximum reward! You may leave now.", TALKTYPE_MONSTER_YELL)
            end
        end
    end
    -- Schedule the function to run again in 60 seconds
    addEvent(participantTimer, 60 * 1000)
end

-- Initial call to the timer function
participantTimer()

function gazHaragothHeal.onThink(creature)
    creature:addCondition(condition)
    -- creature:say("Gaz'haragoth begins to draw on the nightmares to HEAL himself!", TALKTYPE_MONSTER_YELL)
end

gazHaragothHeal:register()