local potionsModal = CreatureEvent("AddonDoll")

function potionsModal.onModalWindow(player, modalWindowId, buttonId, choiceId)
    if modalWindowId == 10001 then
        if buttonId == 101 then -- Botão de compra de 1 item (potion)
            local addondoll_id = 8778
--citizen            
			if player:hasOutfit(136, 2) or player:hasOutfit(128, 2) then
                player:sendTextMessage(MESSAGE_EVENT_ADVANCE, "You already have this outfit.")
                player:getPosition():sendMagicEffect(CONST_ME_POFF) -- Efeito de erro
           elseif player:getItemCount(addondoll_id) >= 1 then
                -- Adiciona addons de mage
                player:addOutfitAddon(136, 1) -- Outfit fem
                player:addOutfitAddon(136, 2) -- Outfit fem
                player:addOutfitAddon(128, 1) -- Outfit m
                player:addOutfitAddon(128, 2) -- Outfit m				
                player:removeItem(addondoll_id, 1)
                player:sendTextMessage(MESSAGE_EVENT_ADVANCE, "You earned citizen outfits.")
                player:getPosition():sendMagicEffect(CONST_ME_GIFT_WRAPS)
            end
--end citizen
        end
    end
    player:unregisterEvent("AddonDoll") -- Corrigido o nome do evento
end

potionsModal:register()