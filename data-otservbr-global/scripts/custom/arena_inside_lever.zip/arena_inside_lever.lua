local rouletteLever = Action()

function rouletteLever.onUse(player, item, fromPosition, target, toPosition, isHotkey)
        for _, spec in pairs(Game.getSpectators(player:getPosition(), false, true, 20, 20, 20, 20)) do
        if spec:isPlayer() then
            local storageValue = spec:getStorageValue(453565651409)
            if spec:getStorageValue(4535656514002) <= os.time() then
                if storageValue == 1 then
                    spec:setStorageValue(453565651409, 2)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                    spec:say("Wave 1 finished, starting wave 2.", TALKTYPE_MONSTER_YELL)
                elseif storageValue == 2 then
                    spec:setStorageValue(453565651409, 3)
                    spec:say("Wave 2 finished, starting wave 3.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 3 then
                    spec:setStorageValue(453565651409, 4)
                    spec:say("Wave 3 finished, starting wave 4.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 4 then
                    spec:setStorageValue(453565651409, 5)
                    spec:say("Wave 4 finished, starting wave 5.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 5 then
                    spec:setStorageValue(453565651409, 6)
                    spec:say("Wave 5 finished, starting wave 6.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 6 then
                    spec:setStorageValue(453565651409, 7)
                    spec:say("Wave 6 finished, starting wave 7.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 7 then
                    spec:setStorageValue(453565651409, 8)
                    spec:say("Wave 7 finished, starting wave 8.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 8 then
                    spec:setStorageValue(453565651409, 9)
                    spec:say("Wave 8 finished, starting wave 9.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 9 then
                    spec:setStorageValue(453565651409, 10)
                    spec:say("Wave 9 finished, starting wave 10.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 10 then
                    spec:setStorageValue(453565651409, 11)
                    spec:say("Wave 10 finished, starting wave 11.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 11 then
                    spec:setStorageValue(453565651409, 12)
                    spec:say("Wave 11 finished, starting wave 12.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 12 then
                    spec:setStorageValue(453565651409, 13)
                    spec:say("Wave 12 finished, starting wave 13.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 13 then
                    spec:setStorageValue(453565651409, 14)
                    spec:say("Wave 13 finished, starting wave 14.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 14 then
                    spec:setStorageValue(453565651409, 15)
                    spec:say("Wave 14 finished, starting wave 15.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 15 then
                    spec:setStorageValue(453565651409, 16)
                    spec:say("Wave 15 finished, starting wave 16.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 16 then
                    spec:setStorageValue(453565651409, 17)
                    spec:say("Wave 16 finished, starting wave 17.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 17 then
                    spec:setStorageValue(453565651409, 18)
                    spec:say("Wave 17 finished, starting wave 18.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 18 then
                    spec:setStorageValue(453565651409, 19)
                    spec:say("Wave 18 finished, starting wave 19.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 19 then
                    spec:setStorageValue(453565651409, 20)
                    spec:say("Wave 19 finished, starting wave 20.", TALKTYPE_MONSTER_YELL)
                    spec:setStorageValue(4535656514002, os.time() + 60)
                elseif storageValue == 20 then
                    spec:setStorageValue(453565651409, 21)
                    spec:say("Wave 20 finished, CONGRATULATIONS! You finished arena and got maximum reward! You may leave now.", TALKTYPE_MONSTER_YELL)
                end
            else
                local remainingTime = spec:getStorageValue(4535656514002) - os.time()
                spec:say("You have to wait " .. remainingTime .. " seconds to pull the lever again!", TALKTYPE_MONSTER_SAY)
            end
        end
    end
    return false
end

rouletteLever:aid(29306)
rouletteLever:register()