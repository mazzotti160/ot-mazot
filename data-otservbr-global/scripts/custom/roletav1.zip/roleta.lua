local config = {
    actionId = 24252,  -- ActionID da alavanca
    requiredItemId = 19082, 
    positions = {
        {x = 32343, y = 32234, z = 7}, -- Posição inicial
        {x = 32344, y = 32234, z = 7},
        {x = 32345, y = 32234, z = 7},
        {x = 32346, y = 32234, z = 7},
        {x = 32347, y = 32234, z = 7}, -- Posição final (centro)
        {x = 32348, y = 32234, z = 7},
        {x = 32349, y = 32234, z = 7},
        {x = 32350, y = 32234, z = 7},
        {x = 32351, y = 32234, z = 7}  -- Posição Final
    },
    items = {
    --    {id = 37317, count = 2, chance = 1, raro = true},
    --    {id = 3043, count = 100, chance = 4},
    --    {id = 3587, count = 1, chance = 1},
	--ids aqui abaixo
	{id = 37110, count = 2, chance = 1},--core
	{id = 37110, count = 5, chance = 1},--core
	{id = 37110, count = 10, chance = 1},--core
        {id = 9598, count = 1, chance = 4}, -- canivete
        {id = 9596, count = 1, chance = 4}, -- canivete
        {id = 9594, count = 1, chance = 4}, -- canivete	
	--rewards
        {id = 25780, count = 1, chance = 1}, -- blossom bag
        {id = 18339, count = 1, chance = 1}, -- zaoan chess box
        {id = 44760, count = 1, chance = 1}, -- bp assets 1321 rosa bonita
        {id = 21445, count = 1, chance = 1}, -- war bp
        {id = 36813, count = 1, chance = 1}, -- galthen sachel
        {id = 39754, count = 1, chance = 1}, -- lilypad bp
        {id = 39693, count = 1, chance = 1}, -- 25y bp
        {id = 37536, count = 1, chance = 1}, -- changing bp
        {id = 32620, count = 1, chance = 1}, -- ghost
        {id = 31625, count = 1, chance = 1}, -- winged
        {id = 30197, count = 1, chance = 1}, -- festive
        {id = 28571, count = 1, chance = 1}, -- book
        {id = 24395, count = 1, chance = 1}, -- 20y bp
        {id = 24393, count = 1, chance = 1}, -- pillow
        {id = 23525, count = 1, chance = 1}, -- energetic
        {id = 22084, count = 1, chance = 1}, -- wolf bp
        {id = 21292, count = 1, chance = 1}, -- feedbag
        {id = 20347, count = 1, chance = 1}, -- cake
        {id = 19159, count = 1, chance = 1}, -- pannier
        {id = 35577, count = 1, chance = 1}, -- raccoon bp
        {id = 14674, count = 1, chance = 1}, -- 15y bp
        {id = 16100, count = 1, chance = 1}, -- crystal bp
        {id = 10346, count = 1, chance = 1}, -- santa bp
        {id = 39546, count = 1, chance = 1}, -- primal bag
        {id = 34109, count = 1, chance = 1}, -- desire
        {id = 43895, count = 1, chance = 1}, -- covet
        {id = 3417, count = 1, chance = 1}, -- shield of honour
        {id = 3438, count = 1, chance = 1}, -- eagle shield
        {id = 3437, count = 1, chance = 1}, -- amazon shield
        {id = 3427, count = 1, chance = 1}, -- rose shield
        {id = 3423, count = 1, chance = 1}, -- blessed shield
        {id = 37607, count = 1, chance = 1}, -- green demon legs
        {id = 3398, count = 1, chance = 1}, -- dwarven legs
        {id = 3389, count = 1, chance = 1}, -- demon legs
        {id = 3363, count = 1, chance = 1}, -- dslegs
        {id = 19366, count = 1, chance = 1}, -- icy cullote
        {id = 10200, count = 1, chance = 1}, -- crystal boots
        {id = 3553, count = 1, chance = 1}, -- bunnyslipper
        {id = 3550, count = 1, chance = 1}, -- patched boots
        {id = 3246, count = 1, chance = 1}, -- boots waterwalking
        {id = 19374, count = 1, chance = 1}, -- vampire silk slipper
        {id = 10201, count = 1, chance = 1}, -- dragon scale boots
        {id = 37610, count = 1, chance = 1}, -- green demon slippers
        {id = 30196, count = 1, chance = 1}, -- yetislipper
        {id = 3397, count = 1, chance = 1}, -- dwarven armor
        {id = 3396, count = 1, chance = 1}, -- dwarven helm
        {id = 37609, count = 1, chance = 1}, -- green demon helm
        {id = 3393, count = 1, chance = 1}, -- amazon helmet
        {id = 37608, count = 1, chance = 1}, -- green demon armor
        {id = 3400, count = 1, chance = 1}, -- dragon scale helmet
        {id = 19372, count = 1, chance = 1}, -- goo shell
        {id = 3395, count = 1, chance = 1}, -- ceremonial mask
        {id = 25779, count = 1, chance = 1}, -- swan feather cloak
        {id = 3368, count = 1, chance = 1}, -- winged helm
        {id = 3011, count = 1, chance = 1}, -- crown
        {id = 3570, count = 1, chance = 1}, -- ball gown
        {id = 3402, count = 1, chance = 1}, -- native armor
        {id = 3365, count = 1, chance = 1}, -- golden helmet
        {id = 3394, count = 1, chance = 1}, -- amazon armor
        {id = 32616, count = 1, chance = 1}, -- phantasmal axe
        {id = 28826, count = 1, chance = 1}, -- deepling fork
        {id = 31614, count = 1, chance = 1}, -- tagralt
        {id = 28825, count = 1, chance = 1}, -- deepling dagger
        {id = 3278, count = 1, chance = 1}, -- magic longsword
        {id = 8103, count = 1, chance = 1}, -- epiphany
        {id = 3296, count = 1, chance = 1}, -- warlord sword
        {id = 8099, count = 1, chance = 1}, -- dark trinity mace
        {id = 8097, count = 1, chance = 1}, -- solar axe
		--craft \/
			{id = 39761, count = 1, chance = 1}, -- gods twilight doll
			{id = 16262, count = 1, chance = 1}, -- dragon eye
			{id = 35909, count = 1, chance = 1}, -- chaos crit dice
			{id = 44759, count = 1, chance = 1}, -- raposinha da bp roxa bonita
			{id = 12809, count = 1, chance = 1}, -- epic wisdom
			{id = 34266, count = 1, chance = 1}, -- tibiapedia
			{id = 22153, count = 1, chance = 1}, -- dark wizard crown
			{id = 44056, count = 1, chance = 1}, -- dragao verde
			{id = 44055, count = 1, chance = 1}, -- shield dragao verde
			{id = 22889, count = 1, chance = 1}, -- shield of destiny
			{id = 39759, count = 1, chance = 1}, -- gods twilight doll golden set
			{id = 25982, count = 1, chance = 1}, -- mathmaster shield
		--craft/\
        {id = 27454, count = 1, chance = 1}, -- hammer destruct
        {id = 27452, count = 1, chance = 1}, -- chopper
        {id = 27450, count = 1, chance = 1}, -- slayer
        {id = 27456, count = 1, chance = 1}, -- cross
        {id = 27458, count = 1, chance = 1}, -- rod
        {id = 27457, count = 1, chance = 1}, -- wand
        {id = 27455, count = 1, chance = 1}, -- bow
        {id = 31579, count = 1, chance = 1 }, --"Embrace of nature"
        {id = 31577, count = 1, chance = 1 }, --"Terra helmet"
        {id = 31578, count = 1, chance = 1 },--"Bear skin"
        {id = 31581, count = 1, chance = 1 },--"Bow of cataclysm"
        {id = 31582, count = 1, chance = 1 },--"Galea mortis"
        {id = 31580, count = 1, chance = 1 },--"Mortal mace"
        {id = 31583, count = 1, chance = 1 },--"Toga mortis"
        {id = 40595, count = 1, chance = 1 },--"Mutant bone kilt"
        {id = 40594, count = 1, chance = 1 },--"Alchemists notepad"
        {id = 40593, count = 1, chance = 1 },--"Mutant bone boots"
        {id = 40592, count = 1, chance = 1 },--"Alchemists boots"
        {id = 40590, count = 1, chance = 1 },--"Mutated skin legs"
        {id = 40589, count = 1, chance = 1 },--"Stitched mutant hide legs"
        {id = 40588, count = 1, chance = 1 },--"Antler horn helmet"
        {id = 40591, count = 1, chance = 1 },--"Mutated skin armor"
        {id = 34080, count = 1, chance = 1 },--"Lion ring"
        {id = 34150, count = 1, chance = 1 },--"Lion longbow"
        {id = 34151, count = 1, chance = 1 },--"Lion rod"
        {id = 34152, count = 1, chance = 1 },--"Lion wand"
        {id = 34153, count = 1, chance = 1 },--"Lion spellbook"
        {id = 34154, count = 1, chance = 1 },--"Lion shield"
        {id = 34155, count = 1, chance = 1 },--"Lion longsword"
        {id = 34156, count = 1, chance = 1 },--"Lion spangehelmet"
        {id = 34157, count = 1, chance = 1 },--"Lion plate"
        {id = 34158, count = 1, chance = 1 },--"Lion amulet"
        {id = 34253, count = 1, chance = 1 },--"Lion axe"
        {id = 34254, count = 1, chance = 1 },--"Lion hammer"
        {id = 39165, count = 1, chance = 1 },--"Midnight Tunic"
        {id = 39167, count = 1, chance = 1 },--"Midnight Sarong"
        {id = 39155, count = 1, chance = 1 },--"Naga Sword"
        {id = 39156, count = 1, chance = 1 },--"Naga Axe"
        {id = 39157, count = 1, chance = 1 },--"Naga Club"
        {id = 39162, count = 1, chance = 1 },--"Naga Wand"
        {id = 39163, count = 1, chance = 1 },--"Naga Rod"
        {id = 39159, count = 1, chance = 1 },--"Naga Crossbow"
        {id = 39160, count = 1, chance = 1 },--"Naga Quiver"
        {id = 39164, count = 1, chance = 1 },--"Dawnfire Sherwani"
        {id = 39166, count = 1, chance = 1 },--"Dawnfire Pantaloons"
        {id = 39233, count = 1, chance = 1 },--"Turtle Amulet"
        {id = 39161, count = 1, chance = 1 },--"Feverbloom Boots"
        {id = 39158, count = 1, chance = 1 },--"Frostflower Boots"
        {id = 27647, count = 1, chance = 1 },--"Gnome helmet"
        {id = 27648, count = 1, chance = 1 },--"Gnome armor"
        {id = 27649, count = 1, chance = 1 },--"Gnome legs"
        {id = 27651, count = 1, chance = 1 },--"Gnome sword"
        {id = 27650, count = 1, chance = 1 },--"Gnome shield"
        {id = 32617, count = 1, chance = 1 },--"Fabulous legs"
        {id = 32618, count = 1, chance = 1 },--"Soulful legs"
        {id = 32628, count = 1, chance = 1 },--"Ghost chestplate"
        {id = 32619, count = 1, chance = 1 },--"Pair of nightmare boots"
        {id = 32616, count = 1, chance = 1 },--"Phantasmal axe"
        {id = 32635, count = 1, chance = 1 },--"Ring of souls"
        {id = 28714, count = 1, chance = 1 },--"Falcon circlet"
        {id = 28715, count = 1, chance = 1 },--"Falcon coif"
        {id = 28716, count = 1, chance = 1 },--"Falcon rod"
        {id = 28717, count = 1, chance = 1 },--"Falcon wand"
        {id = 28718, count = 1, chance = 1 },--"Falcon bow"
        {id = 28719, count = 1, chance = 1 },--"Falcon plate"
        {id = 28720, count = 1, chance = 1 },--"Falcon greaves"
        {id = 28721, count = 1, chance = 1 },--"Falcon shield"
        {id = 28722, count = 1, chance = 1 },--"Falcon escutcheon"
        {id = 28723, count = 1, chance = 1 },--"Falcon longsword"
        {id = 28724, count = 1, chance = 1 },--"Falcon battleaxe"
        {id = 28725, count = 1, chance = 1 },--"Falcon mace"
        {id = 36656, count = 1, chance = 1 },--"Eldritch shield"
        {id = 36657, count = 1, chance = 1 },--"Eldritch claymore"
        {id = 36658, count = 1, chance = 1 },--"Gilded eldritch claymore"
        {id = 36659, count = 1, chance = 1 },--"Eldritch warmace"
        {id = 36660, count = 1, chance = 1 },--"Gilded eldritch warmace"
        {id = 36661, count = 1, chance = 1 },--"Eldritch greataxe"
        {id = 36662, count = 1, chance = 1 },--"Gilded eldritch greataxe"
        {id = 36663, count = 1, chance = 1 },--"Eldritch cuirass"
        {id = 36664, count = 1, chance = 1 },--"Eldritch bow"
        {id = 36665, count = 1, chance = 1 },--"Gilded eldritch bow"
        {id = 36666, count = 1, chance = 1 },--"Eldritch quiver"
        {id = 36667, count = 1, chance = 1 },--"Eldritch breeches"
        {id = 36668, count = 1, chance = 1 },--"Eldritch wand"
        {id = 36669, count = 1, chance = 1 },--"Gilded eldritch wand"
        {id = 36670, count = 1, chance = 1 },--"Eldritch cowl"
        {id = 36671, count = 1, chance = 1 },--"Eldritch hood"
        {id = 36672, count = 1, chance = 1 },--"Eldritch folio"
        {id = 36673, count = 1, chance = 1 },--"Eldritch tome"
        {id = 36674, count = 1, chance = 1 },--"Eldritch rod"
        {id = 36675, count = 1, chance = 1 },--"Gilded eldritch rod"
        {id = 30393, count = 1, chance = 1 },--"Cobra crossbow"
        {id = 30394, count = 1, chance = 1 },--"Cobra boots"
        {id = 30395, count = 1, chance = 1 },--"Cobra club"
        {id = 30396, count = 1, chance = 1 },--"Cobra axe"
        {id = 30397, count = 1, chance = 1 },--"Cobra hood"
        {id = 30398, count = 1, chance = 1 },--"Cobra sword"
        {id = 30399, count = 1, chance = 1 },--"Cobra wand"
        {id = 30400, count = 1, chance = 1 },--"Cobra rod"
        {id = 31631, count = 1, chance = 1 },--"Cobra amulet"
        {id = 29423, count = 1, chance = 1 },--"Dream shroud"
        {id = 29424, count = 1, chance = 1 },--"Pair of dreamwalkers"
        {id = 29418, count = 1, chance = 1 },--"Living armor"
        {id = 29417, count = 1, chance = 1 },--"Living vine bow"
        {id = 29422, count = 1, chance = 1 },--"Winterblade"
        {id = 29421, count = 1, chance = 1 },--"Summerblade"
        {id = 29426, count = 1, chance = 1 },--"Brain in a jar"
        {id = 29425, count = 1, chance = 1 },--"Energized limb"
        {id = 29419, count = 1, chance = 1 },--"Resizer"
        {id = 29420, count = 1, chance = 1 },--"Shoulder plate"
        {id = 29427, count = 1, chance = 1 },--"Dark whispers"
        {id = 30342, count = 1, chance = 1 },--"Sleep shawl"
        {id = 35514, count = 1, chance = 1 },--"Junge flail"
        {id = 35515, count = 1, chance = 1 },--"Throwing axe"
        {id = 35516, count = 1, chance = 1 },--"Exotic legs"
        {id = 35517, count = 1, chance = 1 },--"Bast legs"
        {id = 35518, count = 1, chance = 1 },--"Jungle bow"
        {id = 35519, count = 1, chance = 1 },--"Makeshift boots"
        {id = 35520, count = 1, chance = 1 },--"Make-do boots"
        {id = 35521, count = 1, chance = 1 },--"Jungle rod"
        {id = 35522, count = 1, chance = 1 },--"Jungle wand"
        {id = 35523, count = 1, chance = 1 },--"Exotic amulet"
        {id = 35524, count = 1, chance = 1 },	--"Jungle quiver"
	--ids aqui acima
			}
}

local isRouletteRunning = false

local function addItemToPlayer(player, item)
    player:addItem(item.id, item.count)
    player:sendTextMessage(MESSAGE_EVENT_ADVANCE, "Legal! Ganhou um " .. ItemType(item.id):getName() .. "!")
    player:getPosition():sendMagicEffect(CONST_ME_GIFT_WRAPS)
    if item.raro then
        Game.broadcastMessage(player:getName() .. " ganhou um item raro: " .. ItemType(item.id):getName() .. " na roleta!", MESSAGE_EVENT_ADVANCE)
    end
end

local function getRandomItem()
    local totalWeight = 0
    for _, item in ipairs(config.items) do
        totalWeight = totalWeight + item.chance
    end

    local randomWeight = math.random() * totalWeight
    local cumulativeWeight = 0
    for _, item in ipairs(config.items) do
        cumulativeWeight = cumulativeWeight + item.chance
        if randomWeight <= cumulativeWeight then
            return item
        end
    end
end

local function moveItems()
    for i = #config.positions, 2, -1 do
        local tile = Tile(config.positions[i - 1])
        local item = tile and tile:getTopDownItem()
        if item then
            item:moveTo(config.positions[i])
            --Position(config.positions[i]):sendMagicEffect(CONST_ME_MAGIC_GREEN)
        end
    end
end

local function clearItems()
    for _, pos in ipairs(config.positions) do
        local tile = Tile(Position(pos))
        if tile then
            local item = tile:getTopDownItem()
            while item do
                item:remove()
                item = tile:getTopDownItem()
            end
        end
    end
end

local function createItemWithEffect(position, item)
    Game.createItem(item.id, item.count, Position(position))
    Position(position):sendMagicEffect(CONST_ME_MAGIC_BLUE)
end

local function getItemConfigById(itemId)
    for _, item in ipairs(config.items) do
        if item.id == itemId then
            return item
        end
    end
    return nil
end

local function rouletteAction(player)
    isRouletteRunning = true
    local steps = 35 --+ math.random(5, 10)  -- Número de passos que a roleta dará antes de parar
    local interval = 30  -- Intervalo

    local currentItem = getRandomItem()
    createItemWithEffect(config.positions[1], currentItem)

    for i = 1, steps do
        addEvent(function()
            moveItems()
            if i == steps then
                local winningItem = Tile(Position(config.positions[5])):getTopDownItem()
                if winningItem then
                    clearItems()
                    for _, pos in ipairs(config.positions) do
                        createItemWithEffect(pos, {id = winningItem:getId(), count = winningItem:getCount()})
                    end
                    local itemConfig = getItemConfigById(winningItem:getId())
                    addItemToPlayer(player, itemConfig)
                end
                isRouletteRunning = false
            else
                local lastPositionTile = Tile(Position(config.positions[#config.positions]))
                if lastPositionTile then
                    local lastItem = lastPositionTile:getTopDownItem()
                    if lastItem then
                        lastItem:remove()
                        Position(config.positions[#config.positions]):sendMagicEffect(CONST_ME_POFF)
                    end
                end
                currentItem = getRandomItem()
                createItemWithEffect(config.positions[1], currentItem)
            end
        end, i * interval)

        -- Aumentar o intervalo para simular a desaceleração
        interval = interval + 10
    end
end

local rouletteLever = Action()

function rouletteLever.onUse(player, item, fromPosition, target, toPosition, isHotkey)
    if isRouletteRunning then
        player:sendTextMessage(MESSAGE_EVENT_ADVANCE, "Roleta funcionando. Por favor, espere.")
        return false
    end

    if item.actionid == config.actionId then
        if player:removeItem(config.requiredItemId, 1) then
            clearItems()
            rouletteAction(player)
            return true
        else
            player:sendTextMessage(MESSAGE_EVENT_ADVANCE, "Precisa de um item especial para acionar a roleta.")
            return false
        end
    end
    return false
end

rouletteLever:aid(config.actionId)
rouletteLever:register()
