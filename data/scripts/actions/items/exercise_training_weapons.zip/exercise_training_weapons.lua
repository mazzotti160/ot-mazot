local exhaustionTime = 1

local exerciseWeaponsTable = {
	-- MELEE
	[28552] = { skill = SKILL_SWORD, effect = CONST_ANI_WHIRLWINDSWORD, allowFarUse = true },
	[35279] = { skill = SKILL_SWORD, effect = CONST_ANI_WHIRLWINDSWORD, allowFarUse = true },
	[35285] = { skill = SKILL_SWORD, effect = CONST_ANI_WHIRLWINDSWORD, allowFarUse = true },
	[28553] = { skill = SKILL_AXE, effect = CONST_ANI_WHIRLWINDAXE, allowFarUse = true },
	[35280] = { skill = SKILL_AXE, effect = CONST_ANI_WHIRLWINDAXE, allowFarUse = true },
	[35286] = { skill = SKILL_AXE, effect = CONST_ANI_WHIRLWINDAXE, allowFarUse = true },
	[28554] = { skill = SKILL_CLUB, effect = CONST_ANI_WHIRLWINDCLUB, allowFarUse = true  },
	[35281] = { skill = SKILL_CLUB, effect = CONST_ANI_WHIRLWINDCLUB, allowFarUse = true  },
	[35287] = { skill = SKILL_CLUB, effect = CONST_ANI_WHIRLWINDCLUB, allowFarUse = true  },
	[28540] = { skill = SKILL_SWORD, effect = CONST_ANI_WHIRLWINDSWORD, allowFarUse = true },	
	[28541] = { skill = SKILL_AXE, effect = CONST_ANI_WHIRLWINDAXE, allowFarUse = true },	
	[28542] = { skill = SKILL_CLUB, effect = CONST_ANI_WHIRLWINDCLUB, allowFarUse = true  },		
	-- SHIELD
	[44065] = { skill = SKILL_SHIELD, effect = CONST_ANI_SNOWBALL, allowFarUse = true },
	[44066] = { skill = SKILL_SHIELD, effect = CONST_ANI_SNOWBALL, allowFarUse = true },
	[44067] = { skill = SKILL_SHIELD, effect = CONST_ANI_SNOWBALL, allowFarUse = true },
	[44064] = { skill = SKILL_SHIELD, effect = CONST_ANI_SNOWBALL, allowFarUse = true },	
	-- WAND ROD
	[28556] = { skill = SKILL_MAGLEVEL, effect = CONST_ANI_SMALLICE, allowFarUse = true },
	[35283] = { skill = SKILL_MAGLEVEL, effect = CONST_ANI_SMALLICE, allowFarUse = true },
	[35289] = { skill = SKILL_MAGLEVEL, effect = CONST_ANI_SMALLICE, allowFarUse = true },
	[28544] = { skill = SKILL_MAGLEVEL, effect = CONST_ANI_SMALLICE, allowFarUse = true },		
	[28557] = { skill = SKILL_MAGLEVEL, effect = CONST_ANI_FIRE, allowFarUse = true },
	[35284] = { skill = SKILL_MAGLEVEL, effect = CONST_ANI_FIRE, allowFarUse = true },
	[35290] = { skill = SKILL_MAGLEVEL, effect = CONST_ANI_FIRE, allowFarUse = true },
	[28545] = { skill = SKILL_MAGLEVEL, effect = CONST_ANI_FIRE, allowFarUse = true },	
	-- BOW
	[28555] = { skill = SKILL_DISTANCE, effect = CONST_ANI_SIMPLEARROW, allowFarUse = true },
	[35282] = { skill = SKILL_DISTANCE, effect = CONST_ANI_SIMPLEARROW, allowFarUse = true },
	[35288] = { skill = SKILL_DISTANCE, effect = CONST_ANI_SIMPLEARROW, allowFarUse = true },
	[28543] = { skill = SKILL_DISTANCE, effect = CONST_ANI_SIMPLEARROW, allowFarUse = true },		
}

local dummies = Game.getDummies()

local function leaveExerciseTraining(playerId)
    if _G.OnExerciseTraining[playerId] then
        stopEvent(_G.OnExerciseTraining[playerId].event)
        _G.OnExerciseTraining[playerId] = nil
    end

    local player = Player(playerId)
    if player then
        player:setTraining(false)
    end
    return
end

local function exerciseTrainingEvent(playerId, tilePosition, weaponId, dummyId)
    local player = Player(playerId)
    if not player then
        return leaveExerciseTraining(playerId)
    end

    if player:isTraining() == 0 then
        player:sendTextMessage(MESSAGE_FAILURE, "You have stopped training.")
        return leaveExerciseTraining(playerId)
    end

    if not Tile(tilePosition):getItemById(dummyId) then
        player:sendTextMessage(MESSAGE_FAILURE, "Someone has moved the dummy, the training has stopped.")
        leaveExerciseTraining(playerId)
        return false
    end

    local playerPosition = player:getPosition()
    if not playerPosition:isProtectionZoneTile() then
        player:sendTextMessage(MESSAGE_FAILURE, "You are no longer in a protection zone, the training has stopped.")
        leaveExerciseTraining(playerId)
        return false
    end

    if player:getItemCount(weaponId) <= 0 then
        player:sendTextMessage(MESSAGE_FAILURE, "You need the training weapon in the backpack, the training has stopped.")
        leaveExerciseTraining(playerId)
        return false
    end

    local weapon = player:getItemById(weaponId, true)
    if not weapon:isItem() or not weapon:hasAttribute(ITEM_ATTRIBUTE_CHARGES) then
        player:sendTextMessage(MESSAGE_FAILURE, "The selected item is not a training weapon, the training has stopped.")
        leaveExerciseTraining(playerId)
        return false
    end

    local weaponCharges = weapon:getAttribute(ITEM_ATTRIBUTE_CHARGES)
    if weapon:getAttribute(ITEM_ATTRIBUTE_CHARGES) <= 0 then
        weapon:remove(1)
        local weapon = player:getItemById(weaponId, true)
        if not weapon or (not weapon:isItem() or not weapon:hasAttribute(ITEM_ATTRIBUTE_CHARGES)) then
            player:sendTextMessage(MESSAGE_EVENT_ADVANCE, "Your training weapon has disappeared.")
            leaveExerciseTraining(playerId)
            return false
        end
    end

    if not dummies[dummyId] then
        return false
    end

    local rate = dummies[dummyId] / 100
    local isMagic = exerciseWeaponsTable[weaponId].skill == SKILL_MAGLEVEL
    local isShield = exerciseWeaponsTable[weaponId].skill == SKILL_SHIELD
    if isMagic then
        player:addManaSpent(500 * rate)
        player:addSkillTries(SKILL_FIST, 15 * rate)
    elseif isShield then
        player:addSkillTries(exerciseWeaponsTable[weaponId].skill, 7 * rate)
        player:addSkillTries(SKILL_FIST, 15 * rate * 2)
    else
        player:addSkillTries(exerciseWeaponsTable[weaponId].skill, 7 * rate)
        player:addSkillTries(SKILL_FIST, 15 * rate)
    end

    weapon:setAttribute(ITEM_ATTRIBUTE_CHARGES, (weaponCharges - 1))
    tilePosition:sendMagicEffect(CONST_ME_HITAREA)

    if exerciseWeaponsTable[weaponId].effect then
        playerPosition:sendDistanceEffect(tilePosition, exerciseWeaponsTable[weaponId].effect)
    end

    local rateSpeed = configManager.getFloat(configKeys.RATE_EXERCISE_TRAINING_SPEED) 
    local eventInterval = 2000 / rateSpeed -- 2000 ms (2 segundos) ajustado pelo rate do config
    _G.OnExerciseTraining[playerId].event = addEvent(exerciseTrainingEvent, eventInterval, playerId, tilePosition, weaponId, dummyId)
    return true
end

local function isDummy(id)
    return dummies[id] and dummies[id] > 0
end

local exerciseTraining = Action()

function exerciseTraining.onUse(player, item, fromPosition, target, toPosition, isHotkey)
    if not target or type(target) == "table" or not target:getId() then
        return true
    end

    local playerId = player:getId()
    local targetId = target:getId()

    if target:isItem() and isDummy(targetId) then
        if _G.OnExerciseTraining[playerId] then
            player:sendTextMessage(MESSAGE_FAILURE, "You are already training!")
            return true
        end

        local playerPos = player:getPosition()
        if not exerciseWeaponsTable[item.itemid].allowFarUse and (playerPos:getDistance(target:getPosition()) > 1) then
            player:sendTextMessage(MESSAGE_FAILURE, "Get closer to the dummy.")
            return true
        end

        if not playerPos:isProtectionZoneTile() then
            player:sendTextMessage(MESSAGE_FAILURE, "You need to be in a protection zone.")
            return true
        end

        local playerHouse = player:getTile():getHouse()
        local targetPos = target:getPosition()
        local targetHouse = Tile(targetPos):getHouse()

        if targetHouse and isDummy(targetId) then
            if playerHouse ~= targetHouse then
                player:sendTextMessage(MESSAGE_EVENT_ADVANCE, "You must be inside the house to use this dummy.")
                return true
            end

            local playersOnDummy = 0
            for _, playerTraining in pairs(_G.OnExerciseTraining) do
                if playerTraining.dummyPos == targetPos then
                    playersOnDummy = playersOnDummy + 1
                end

                if playersOnDummy >= configManager.getNumber(configKeys.MAX_ALLOWED_ON_A_DUMMY) then
                    player:sendTextMessage(MESSAGE_FAILURE, "That exercise dummy is busy.")
                    return true
                end
            end
        end

        if player:hasExhaustion("training-exhaustion") then
            player:sendTextMessage(MESSAGE_FAILURE, "This exercise dummy can only be used after a " .. exhaustionTime .. " seconds cooldown.")
            return true
        end

        _G.OnExerciseTraining[playerId] = {}
        if not _G.OnExerciseTraining[playerId].event then
            _G.OnExerciseTraining[playerId].event = addEvent(exerciseTrainingEvent, 0, playerId, targetPos, item.itemid, targetId)
            _G.OnExerciseTraining[playerId].dummyPos = targetPos
            player:setTraining(true)
            player:setExhaustion("training-exhaustion", exhaustionTime)
            player:sendTextMessage(MESSAGE_EVENT_ADVANCE, "You have started training on an exercise dummy.")
        end
        return true
    end
    return false
end

for weaponId, weapon in pairs(exerciseWeaponsTable) do
    exerciseTraining:id(weaponId)
    if weapon.allowFarUse then
        exerciseTraining:allowFarUse(true)
    end
end

exerciseTraining:register()
