local outfits = {
    -- ["outfit"] = {female, male}
    ["citizen"] = {136, 128},
    ["hunter"] = {137, 129},
    ["mage"] = {138, 133},
    ["knight"] = {139, 131},
    ["noblewoman"] = {140, 132},
    ["summoner"] = {141, 133},
    ["warrior"] = {142, 134},
    ["barbarian"] = {147, 143},
    ["druid"] = {148, 144},
    ["wizard"] = {149, 145},
    ["oriental"] = {150, 146},
    ["pirate"] = {155, 151},
    ["assassin"] = {156, 152},
    ["beggar"] = {157, 153},
    ["shaman"] = {158, 154},
    ["norsewoman"] = {252, 251},
    ["nightmare"] = {269, 268},
    ["jester"] = {270, 273},
    ["brotherhood"] = {279, 278},
    ["demon hunter"] = {288, 289},
    ["yalaharian"] = {324, 325},
    ["newly wed"] = {329, 328},
    ["warmaster"] = {336, 335},
    ["wayfarer"] = {366, 367},
    ["afflicted"] = {431, 430},
    ["elementalist"] = {433, 432},
    ["deepling"] = {464, 463},
    ["insectoid"] = {466, 465},
    ["crystal warlord"] = {513, 512},
    ["soil guardian"] = {514, 516},
    ["demon"] = {542, 541},
    ["cave explorer"] = {575, 574},
    ["dream warden"] = {578, 577},
    ["glooth engineer"] = {618, 610},
    ["jersey"] = {620, 619},
    ["recruiter"] = {745, 746},
    ["rift warrior"] = {845, 846},
    ["festive"] = {929, 931},
    ["makeshift warrior"] = {1043, 1042},
    ["battle mage"] = {1070, 1069},
    ["discoverer"] = {1095, 1094},
    ["dream warrior"] = {1147, 1146},
    ["percht raider"] = {1162, 1161},
    ["golden"] = {1211, 1210},
    ["hand of the inquisition"] = {1244, 1243},
    ["orcsoberfest garb"] = {1252, 1251},
    ["poltergeist"] = {1271, 1270},
    ["falconer"] = {1283, 1282},
    ["revenant"] = {1323, 1322},
    ["rascoohan"] = {1372, 1371},
    ["citizen of issavi"] = {1387, 1386},
    ["royal bounacean advisor"] = {1437, 1436},
    ["fire-fighter"] = {1569, 1568},
    ["ancient aucar"] = {1598, 1597},
    ["decaying defender"] = {1663, 1662},
    ["draccoon herald"] = {1723, 1722},
    ["rootwalker"] = {1775, 1774},
}

local addondoll_id = 8778

local addonDoll = TalkAction("!addon")

function addonDoll.onSay(player, words, param)
    if player:getItemCount(addondoll_id) <= 0 then
        player:sendTextMessage(MESSAGE_EVENT_ADVANCE, "You don't have the addon doll!")
        return false
    end

    local split = param:split(",")
    local addonType = split[1] and split[1]:lower():trim()
    if not addonType or (addonType ~= "first" and addonType ~= "second") then
        player:sendTextMessage(MESSAGE_EVENT_ADVANCE, "Please use the command correctly. Example: '!addon first, mage'.")
        return false
    end

    local outfitName = split[2] and split[2]:lower():trim()
    if not outfitName or not outfits[outfitName] then
        player:sendTextMessage(MESSAGE_EVENT_ADVANCE, "There is no outfit with that name.")
        return false
    end

    local type = addonType == "first" and 1 or 2
    if player:hasOutfit(outfits[outfitName][type], type) then
        player:sendTextMessage(MESSAGE_EVENT_ADVANCE, "You already have this addon!")
        return false
    end

    player:removeItem(addondoll_id, 1)
    player:getPosition():sendMagicEffect(CONST_ME_GIFT_WRAPS)
    player:addOutfitAddon(outfits[outfitName][type], type)
  --  player:sendTextMessage(MESSAGE_EVENT_ADVANCE, string.format("You have received the %s addon for the %s outfit.", addonType, outfitName))
	        player:sendTextMessage(MESSAGE_EVENT_ADVANCE, "You have received your addon!'.")
    return false
end

addonDoll:separator(" ")
addonDoll:groupType("normal")
addonDoll:register()
